var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var HierarchySlicer1458836712039;
        (function (HierarchySlicer1458836712039) {
            var SelectionManager = visuals.utility.SelectionManager;
            var createClassAndSelector = jsCommon.CssConstants.createClassAndSelector;
            var PixelConverter = jsCommon.PixelConverter;
            var TreeViewFactory;
            (function (TreeViewFactory) {
                function createListView(options) {
                    return new TreeView(options);
                }
                TreeViewFactory.createListView = createListView;
            })(TreeViewFactory = HierarchySlicer1458836712039.TreeViewFactory || (HierarchySlicer1458836712039.TreeViewFactory = {}));
            /**
             * A UI Virtualized List, that uses the D3 Enter, Update & Exit pattern to update rows.
             * It can create lists containing either HTML or SVG elements.
             */
            var TreeView = (function () {
                function TreeView(options) {
                    var _this = this;
                    // make a copy of options so that it is not modified later by caller
                    this.options = $.extend(true, {}, options);
                    this.scrollbarInner = options.baseContainer.append('div').classed('scrollbar-inner', true).on('scroll', function () { return _this.renderImpl(_this.options.rowHeight); });
                    this.scrollContainer = this.scrollbarInner.append('div').classed('scrollRegion', true);
                    this.visibleGroupContainer = this.scrollContainer.append('div').classed('visibleGroup', true);
                    var scrollInner = $(this.scrollbarInner.node());
                    $(options.baseContainer.node()).find('.scroll-element').attr('drag-resize-disabled', 'true');
                    TreeView.SetDefaultOptions(options);
                }
                TreeView.SetDefaultOptions = function (options) {
                    options.rowHeight = options.rowHeight || TreeView.defaultRowHeight;
                };
                TreeView.prototype.rowHeight = function (rowHeight) {
                    this.options.rowHeight = Math.ceil(rowHeight) + 2; // Margin top/bottom
                    return this;
                };
                TreeView.prototype.data = function (data, getDatumIndex, dataReset) {
                    if (dataReset === void 0) { dataReset = false; }
                    this._data = data;
                    this.getDatumIndex = getDatumIndex;
                    this.setTotalRows();
                    if (dataReset)
                        $(this.scrollbarInner.node()).scrollTop(0);
                    this.render();
                    return this;
                };
                TreeView.prototype.viewport = function (viewport) {
                    this.options.viewport = viewport;
                    this.render();
                    return this;
                };
                TreeView.prototype.empty = function () {
                    this._data = [];
                    this.render();
                };
                TreeView.prototype.render = function () {
                    var _this = this;
                    if (this.renderTimeoutId)
                        window.clearTimeout(this.renderTimeoutId);
                    this.renderTimeoutId = window.setTimeout(function () {
                        _this.renderImpl(_this.options.rowHeight);
                        _this.renderTimeoutId = undefined;
                    }, 240);
                };
                TreeView.prototype.renderImpl = function (rowHeight) {
                    var totalHeight = this.options.scrollEnabled ? Math.max(0, (this._totalRows * rowHeight)) : this.options.viewport.height;
                    this.scrollbarInner.style('height', this.options.viewport.height + "px").attr('height', this.options.viewport.height);
                    this.scrollContainer.style('height', totalHeight + "px").attr('height', totalHeight);
                    this.scrollToFrame(true);
                };
                TreeView.prototype.scrollToFrame = function (loadMoreData) {
                    var options = this.options;
                    var visibleGroupContainer = this.visibleGroupContainer;
                    var totalRows = this._totalRows;
                    var rowHeight = options.rowHeight || TreeView.defaultRowHeight;
                    var visibleRows = this.getVisibleRows() || 1;
                    var scrollTop = this.scrollbarInner.node().scrollTop;
                    var scrollPosition = (scrollTop === 0) ? 0 : Math.floor(scrollTop / rowHeight);
                    var transformAttr = visuals.SVGUtil.translateWithPixels(0, scrollPosition * rowHeight);
                    visibleGroupContainer.style({
                        //order matters for proper overriding
                        'transform': function (d) { return transformAttr; },
                        '-webkit-transform': transformAttr
                    });
                    var position0 = Math.max(0, Math.min(scrollPosition, totalRows - visibleRows + 1)), position1 = position0 + visibleRows;
                    if (this.options.scrollEnabled) {
                        // Subtract the amount of height of the top row that's hidden when it's partially visible.
                        var topRowHiddenHeight = scrollTop - (scrollPosition * rowHeight);
                        var halfRowHeight = rowHeight * 0.5;
                        // If more than half the top row is hidden, we'll need to render an extra item at the bottom
                        if (topRowHiddenHeight > halfRowHeight) {
                            position1++; // Add 1 to handle when rows are partially visible (when scrolling)
                        }
                    }
                    var rowSelection = visibleGroupContainer.selectAll(".row").data(this._data.slice(position0, Math.min(position1, totalRows)), this.getDatumIndex);
                    rowSelection.enter().append('div').classed('row', true).call(function (d) { return options.enter(d); });
                    rowSelection.order();
                    var rowUpdateSelection = visibleGroupContainer.selectAll('.row:not(.transitioning)');
                    rowUpdateSelection.call(function (d) { return options.update(d); });
                    rowSelection.exit().call(function (d) { return options.exit(d); }).remove();
                    if (loadMoreData && visibleRows !== totalRows && position1 >= totalRows * TreeView.loadMoreDataThreshold)
                        options.loadMoreData();
                };
                TreeView.prototype.setTotalRows = function () {
                    var data = this._data;
                    this._totalRows = data ? data.length : 0;
                };
                TreeView.prototype.getVisibleRows = function () {
                    var minimumVisibleRows = 1;
                    var rowHeight = this.options.rowHeight;
                    var viewportHeight = this.options.viewport.height;
                    if (!rowHeight || rowHeight < 1)
                        return minimumVisibleRows;
                    if (this.options.scrollEnabled)
                        return Math.min(Math.ceil(viewportHeight / rowHeight), this._totalRows) || minimumVisibleRows;
                    return Math.min(Math.floor(viewportHeight / rowHeight), this._totalRows) || minimumVisibleRows;
                };
                /**
                 * The value indicates the percentage of data already shown
                 * in the list view that triggers a loadMoreData call.
                 */
                TreeView.loadMoreDataThreshold = 0.8;
                TreeView.defaultRowHeight = 1;
                return TreeView;
            })();
            var HierarchySlicerWebBehavior = (function () {
                function HierarchySlicerWebBehavior() {
                    this.initFilter = true;
                }
                HierarchySlicerWebBehavior.prototype.bindEvents = function (options, selectionHandler) {
                    var _this = this;
                    var expanders = this.expanders = options.expanders;
                    var slicers = this.slicers = options.slicerItemContainers;
                    this.slicerItemLabels = options.slicerItemLabels;
                    this.slicerItemInputs = options.slicerItemInputs;
                    this.dataPoints = options.dataPoints;
                    this.interactivityService = options.interactivityService;
                    this.selectionHandler = selectionHandler;
                    this.settings = options.slicerSettings;
                    this.hostServices = options.hostServices;
                    this.levels = options.levels;
                    this.options = options;
                    var slicerClear = options.slicerClear;
                    var slicerExpand = options.slicerExpand;
                    var slicerCollapse = options.slicerCollapse;
                    if ((this.dataPoints.filter(function (d) { return d.selected; }).length > 0) && this.initFilter) {
                        this.initFilter = false;
                        this.applyFilter();
                    }
                    expanders.on("click", function (d, i) {
                        d.isExpand = !d.isExpand;
                        var currentExpander = expanders.filter(function (e, l) { return i === l; });
                        $(currentExpander[0][0].firstChild).remove(); // remove expand/collapse icon
                        var spinner = currentExpander.append("div").classed("xsmall", true).classed("powerbi-spinner", true).style({
                            'margin': '0px;',
                            'padding-left': '5px;',
                            'display': 'block;',
                        }).attr("ng-if", "viewModel.showProgressBar").attr("delay", "500").append("div").classed("spinner", true);
                        for (var i = 0; i < 5; i++) {
                            spinner.append("div").classed("circle", true);
                        }
                        _this.persistExpand(false);
                    });
                    slicerCollapse.on("click", function (d) {
                        _this.dataPoints.filter(function (d) { return !d.isLeaf; }).forEach(function (d) { return d.isExpand = false; });
                        _this.persistExpand(true);
                    });
                    slicerExpand.on("click", function (d) {
                        _this.dataPoints.filter(function (d) { return !d.isLeaf; }).forEach(function (d) { return d.isExpand = true; });
                        _this.persistExpand(true);
                    });
                    options.slicerContainer.classed('hasSelection', true);
                    slicers.on("mouseover", function (d) {
                        if (d.selectable) {
                            d.mouseOver = true;
                            d.mouseOut = false;
                            _this.renderMouseover();
                        }
                    });
                    slicers.on("mouseout", function (d) {
                        if (d.selectable) {
                            d.mouseOver = false;
                            d.mouseOut = true;
                            _this.renderMouseover();
                        }
                    });
                    slicers.on("click", function (d, index) {
                        if (!d.selectable) {
                            return;
                        }
                        var settings = _this.settings;
                        d3.event.preventDefault();
                        if (!settings.general.singleselect) {
                            var selected = d.selected;
                            d.selected = !selected; // Toggle selection
                            if (!selected || !d.isLeaf) {
                                var selectDataPoints = _this.dataPoints.filter(function (dp) { return dp.parentId.indexOf(d.ownId) >= 0; });
                                for (var i = 0; i < selectDataPoints.length; i++) {
                                    if (selected === selectDataPoints[i].selected) {
                                        selectDataPoints[i].selected = !selected;
                                    }
                                }
                                selectDataPoints = _this.getParentDataPoints(_this.dataPoints, d.parentId);
                                for (var i = 0; i < selectDataPoints.length; i++) {
                                    if (!selected && !selectDataPoints[i].selected) {
                                        selectDataPoints[i].selected = !selected;
                                    }
                                    else if (selected && (_this.dataPoints.filter(function (dp) { return dp.selected && dp.level === d.level && dp.parentId === d.parentId; }).length === 0)) {
                                        selectDataPoints[i].selected = !selected;
                                    }
                                }
                            }
                            if (d.isLeaf) {
                                if (_this.dataPoints.filter(function (d) { return d.selected && d.isLeaf; }).length === 0) {
                                    _this.dataPoints.map(function (d) { return d.selected = false; }); // Clear selection
                                }
                            }
                        }
                        else {
                            var selected = d.selected;
                            _this.dataPoints.map(function (d) { return d.selected = false; }); // Clear selection
                            if (!selected) {
                                var selectDataPoints = [d]; //Self
                                selectDataPoints = selectDataPoints.concat(_this.dataPoints.filter(function (dp) { return dp.parentId.indexOf(d.ownId) >= 0; })); // Children
                                selectDataPoints = selectDataPoints.concat(_this.getParentDataPoints(_this.dataPoints, d.parentId)); // Parents
                                if (selectDataPoints) {
                                    for (var i = 0; i < selectDataPoints.length; i++) {
                                        selectDataPoints[i].selected = true;
                                    }
                                }
                            }
                        }
                        _this.applyFilter();
                    });
                    slicerClear.on("click", function (d) {
                        _this.selectionHandler.handleClearSelection();
                        _this.persistFilter(null);
                    });
                };
                HierarchySlicerWebBehavior.prototype.renderMouseover = function () {
                    var _this = this;
                    this.slicerItemLabels.style({
                        'color': function (d) {
                            if (d.mouseOver)
                                return _this.settings.slicerText.hoverColor;
                            else if (d.mouseOut) {
                                if (d.selected)
                                    return _this.settings.slicerText.selectedColor;
                                else
                                    return _this.settings.slicerText.fontColor;
                            }
                            else if (d.selected)
                                return _this.settings.slicerText.selectedColor;
                            else
                                return _this.settings.slicerText.fontColor;
                        }
                    });
                    this.slicerItemInputs.select('span').style({
                        'background-color': function (d) {
                            if (d.mouseOver)
                                return null;
                            else if (d.mouseOut) {
                                if (d.selected)
                                    return _this.settings.slicerText.selectedColor;
                                else
                                    return null;
                            }
                            else if (d.selected)
                                return _this.settings.slicerText.selectedColor;
                            else
                                return null;
                        }
                    });
                };
                HierarchySlicerWebBehavior.prototype.renderSelection = function (hasSelection) {
                    if (!hasSelection && !this.interactivityService.isSelectionModeInverted()) {
                        this.slicerItemInputs.filter('.selected').classed('selected', false);
                        this.slicerItemInputs.filter('.partiallySelected').classed('partiallySelected', false);
                        var input = this.slicerItemInputs.selectAll('input');
                        if (input) {
                            input.property('checked', false);
                        }
                    }
                    else {
                        this.styleSlicerInputs(this.slicers, hasSelection);
                    }
                };
                HierarchySlicerWebBehavior.prototype.styleSlicerInputs = function (slicers, hasSelection) {
                    slicers.each(function (d) {
                        var slicerItem = this.getElementsByTagName('div')[0];
                        var shouldCheck = d.selected;
                        var partialCheck = false;
                        var input = slicerItem.getElementsByTagName('input')[0];
                        if (input)
                            input.checked = shouldCheck;
                        if (shouldCheck && partialCheck)
                            slicerItem.classList.add('partiallySelected');
                        else if (shouldCheck && (!partialCheck))
                            slicerItem.classList.add('selected');
                        else
                            slicerItem.classList.remove('selected');
                    });
                };
                HierarchySlicerWebBehavior.prototype.applyFilter = function () {
                    if (this.dataPoints.length === 0) {
                        return;
                    }
                    var selectNrValues = 0;
                    var filter;
                    var rootLevels = this.dataPoints.filter(function (d) { return d.level === 0 && d.selected; });
                    if (!rootLevels || (rootLevels.length === 0)) {
                        this.selectionHandler.handleClearSelection();
                        this.persistFilter(null);
                    }
                    else {
                        selectNrValues++;
                        var children = this.getChildFilters(this.dataPoints, rootLevels[0].ownId, 1);
                        var rootFilters = [];
                        if (children) {
                            rootFilters.push(powerbi.data.SQExprBuilder.and(rootLevels[0].id, children.filters));
                            selectNrValues += children.memberCount;
                        }
                        else {
                            rootFilters.push(rootLevels[0].id);
                        }
                        if (rootLevels.length > 1) {
                            for (var i = 1; i < rootLevels.length; i++) {
                                selectNrValues++;
                                children = this.getChildFilters(this.dataPoints, rootLevels[i].ownId, 1);
                                if (children) {
                                    rootFilters.push(powerbi.data.SQExprBuilder.and(rootLevels[i].id, children.filters));
                                    selectNrValues += children.memberCount;
                                }
                                else {
                                    rootFilters.push(rootLevels[i].id);
                                }
                            }
                        }
                        var rootFilter = rootFilters[0];
                        for (var i = 1; i < rootFilters.length; i++) {
                            rootFilter = powerbi.data.SQExprBuilder.or(rootFilter, rootFilters[i]);
                        }
                        if (selectNrValues > 120) {
                        }
                        filter = powerbi.data.SemanticFilter.fromSQExpr(rootFilter);
                        this.persistFilter(filter);
                    }
                };
                HierarchySlicerWebBehavior.prototype.getParentDataPoints = function (dataPoints, parentId) {
                    var parent = dataPoints.filter(function (d) { return d.ownId === parentId; });
                    if (!parent || (parent.length === 0)) {
                        return [];
                    }
                    else if (parent[0].level === 0) {
                        return parent;
                    }
                    else {
                        var returnParents = [];
                        returnParents = returnParents.concat(parent, this.getParentDataPoints(dataPoints, parent[0].parentId));
                        return returnParents;
                    }
                };
                HierarchySlicerWebBehavior.prototype.getChildFilters = function (dataPoints, parentId, level) {
                    var memberCount = 0;
                    var childFilters = dataPoints.filter(function (d) { return d.level === level && d.parentId === parentId && d.selected; });
                    var totalChildren = dataPoints.filter(function (d) { return d.level === level && d.parentId === parentId; }).length;
                    if (!childFilters || (childFilters.length === 0)) {
                        return;
                    }
                    else if (childFilters[0].isLeaf) {
                        if ((totalChildren !== childFilters.length) || this.options.slicerSettings.general.selfFilterEnabled) {
                            var returnFilter = childFilters[0].id;
                            memberCount += childFilters.length;
                            if (childFilters.length > 1) {
                                for (var i = 1; i < childFilters.length; i++) {
                                    returnFilter = powerbi.data.SQExprBuilder.or(returnFilter, childFilters[i].id);
                                }
                            }
                            return {
                                filters: returnFilter,
                                memberCount: memberCount,
                            };
                        }
                        else {
                            return;
                        }
                    }
                    else {
                        var returnFilter;
                        var allSelected = (totalChildren === childFilters.length);
                        memberCount += childFilters.length;
                        for (var i = 0; i < childFilters.length; i++) {
                            var childChildFilter = this.getChildFilters(dataPoints, childFilters[i].ownId, level + 1);
                            if ((childChildFilter) || this.options.slicerSettings.general.selfFilterEnabled) {
                                allSelected = false;
                                memberCount += childChildFilter.memberCount;
                                if (returnFilter) {
                                    returnFilter = powerbi.data.SQExprBuilder.or(returnFilter, powerbi.data.SQExprBuilder.and(childFilters[i].id, childChildFilter.filters));
                                }
                                else {
                                    returnFilter = powerbi.data.SQExprBuilder.and(childFilters[i].id, childChildFilter.filters);
                                }
                            }
                            else {
                                if (returnFilter) {
                                    returnFilter = powerbi.data.SQExprBuilder.or(returnFilter, childFilters[i].id);
                                }
                                else {
                                    returnFilter = childFilters[i].id;
                                }
                            }
                        }
                        return allSelected ? undefined : {
                            filters: returnFilter,
                            memberCount: memberCount,
                        };
                    }
                };
                HierarchySlicerWebBehavior.prototype.persistFilter = function (filter) {
                    var properties = {};
                    if (filter) {
                        properties[HierarchySlicer1458836712039.hierarchySlicerProperties.filterPropertyIdentifier.propertyName] = filter;
                    }
                    else {
                        properties[HierarchySlicer1458836712039.hierarchySlicerProperties.filterPropertyIdentifier.propertyName] = "";
                    }
                    var filterValues = this.dataPoints.filter(function (d) { return d.selected; }).map(function (d) { return d.ownId; }).join(',');
                    if (filterValues) {
                        properties[HierarchySlicer1458836712039.hierarchySlicerProperties.filterValuePropertyIdentifier.propertyName] = filterValues;
                    }
                    else {
                        properties[HierarchySlicer1458836712039.hierarchySlicerProperties.filterValuePropertyIdentifier.propertyName] = "";
                    }
                    var objects = {
                        merge: [
                            {
                                objectName: HierarchySlicer1458836712039.hierarchySlicerProperties.filterPropertyIdentifier.objectName,
                                selector: undefined,
                                properties: properties,
                            }
                        ]
                    };
                    this.hostServices.persistProperties(objects);
                    this.hostServices.onSelect({ data: [] });
                };
                HierarchySlicerWebBehavior.prototype.persistExpand = function (updateScrollbar) {
                    var properties = {};
                    properties[HierarchySlicer1458836712039.hierarchySlicerProperties.expandedValuePropertyIdentifier.propertyName] = this.dataPoints.filter(function (d) { return d.isExpand; }).map(function (d) { return d.ownId; }).join(',');
                    var objects = {
                        merge: [
                            {
                                objectName: HierarchySlicer1458836712039.hierarchySlicerProperties.expandedValuePropertyIdentifier.objectName,
                                selector: undefined,
                                properties: properties,
                            }
                        ]
                    };
                    this.hostServices.persistProperties(objects);
                    this.hostServices.onSelect({ data: [] });
                };
                return HierarchySlicerWebBehavior;
            })();
            HierarchySlicer1458836712039.HierarchySlicerWebBehavior = HierarchySlicerWebBehavior;
            HierarchySlicer1458836712039.hierarchySlicerProperties = {
                selection: {
                    singleselect: { objectName: 'selection', propertyName: 'singleSelect' },
                    emptyLeafs: { objectName: 'selection', propertyName: 'emptyLeafs' }
                },
                header: {
                    show: { objectName: 'header', propertyName: 'show' },
                    title: { objectName: 'header', propertyName: 'title' },
                    fontColor: { objectName: 'header', propertyName: 'fontColor' },
                    background: { objectName: 'header', propertyName: 'background' },
                    textSize: { objectName: 'header', propertyName: 'textSize' },
                },
                items: {
                    fontColor: { objectName: 'items', propertyName: 'fontColor' },
                    selectedColor: { objectName: 'items', propertyName: 'selectedColor' },
                    background: { objectName: 'items', propertyName: 'background' },
                    textSize: { objectName: 'items', propertyName: 'textSize' },
                },
                selectedPropertyIdentifier: { objectName: 'general', propertyName: 'selected' },
                expandedValuePropertyIdentifier: { objectName: 'general', propertyName: 'expanded' },
                filterPropertyIdentifier: { objectName: 'general', propertyName: 'filter' },
                filterValuePropertyIdentifier: { objectName: 'general', propertyName: 'filterValues' },
                defaultValue: { objectName: 'general', propertyName: 'defaultValue' },
                selfFilterEnabled: { objectName: 'general', propertyName: 'selfFilterEnabled' },
                // store version
                version: { objectName: 'general', propertyName: 'version' },
            };
            var HierarchySlicer = (function () {
                function HierarchySlicer(options) {
                    if (options) {
                        if (options.margin) {
                            this.margin = options.margin;
                        }
                        if (options.behavior) {
                            this.behavior = options.behavior;
                        }
                    }
                    if (!this.behavior) {
                        this.behavior = new HierarchySlicerWebBehavior();
                    }
                }
                HierarchySlicer.DefaultSlicerSettings = function () {
                    return {
                        general: {
                            rows: 0,
                            singleselect: true,
                            showDisabled: "",
                            outlineColor: '#808080',
                            outlineWeight: 1,
                            selfFilterEnabled: false,
                            version: 801,
                            emptyLeafs: true
                        },
                        margin: {
                            top: 50,
                            bottom: 50,
                            right: 50,
                            left: 50
                        },
                        header: {
                            borderBottomWidth: 1,
                            show: true,
                            outline: 'BottomOnly',
                            fontColor: '#666666',
                            background: undefined,
                            textSize: 10,
                            outlineColor: '#a6a6a6',
                            outlineWeight: 1,
                            title: '',
                        },
                        headerText: {
                            marginLeft: 8,
                            marginTop: 0
                        },
                        slicerText: {
                            textSize: 10,
                            height: 18,
                            width: 0,
                            fontColor: '#666666',
                            hoverColor: '#212121',
                            selectedColor: '#333333',
                            unselectedColor: '#ffffff',
                            disabledColor: 'grey',
                            marginLeft: 8,
                            outline: 'Frame',
                            background: undefined,
                            transparency: 0,
                            outlineColor: '#000000',
                            outlineWeight: 1,
                            borderStyle: 'Cut',
                        },
                        slicerItemContainer: {
                            // The margin is assigned in the less file. This is needed for the height calculations.
                            marginTop: 5,
                            marginLeft: 0,
                        },
                    };
                };
                HierarchySlicer.prototype.converter = function (dataView, searchText) {
                    if (!dataView || !dataView.table || !dataView.table.rows || !(dataView.table.rows.length > 0) || !dataView.table.columns || !(dataView.table.columns.length > 0)) {
                        return {
                            dataPoints: [],
                            settings: null,
                            levels: null,
                        };
                    }
                    var rows = dataView.table.rows;
                    var columns = dataView.table.columns;
                    var levels = rows[0].length - 1;
                    var dataPoints = [];
                    var defaultSettings = HierarchySlicer.DefaultSlicerSettings();
                    var identityValues = [];
                    var selectedIds = [];
                    var expandedIds = [];
                    var selectionFilter;
                    var order = 0;
                    var objects = dataView.metadata.objects;
                    var isRagged = false;
                    var raggedParents = [];
                    defaultSettings.general.singleselect = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selection.singleselect, defaultSettings.general.singleselect);
                    defaultSettings.general.emptyLeafs = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selection.emptyLeafs, defaultSettings.general.singleselect);
                    defaultSettings.header.title = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.title, dataView.metadata.columns[0].displayName);
                    selectedIds = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.filterValuePropertyIdentifier, "").split(',');
                    expandedIds = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.expandedValuePropertyIdentifier, "").split(',');
                    defaultSettings.general.selfFilterEnabled = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selfFilterEnabled, defaultSettings.general.selfFilterEnabled);
                    for (var r = 0; r < rows.length; r++) {
                        var parentExpr = null;
                        var parentId = '';
                        for (var c = 0; c < rows[r].length; c++) {
                            if ((rows[r][c] === null) && (!defaultSettings.general.emptyLeafs)) {
                                isRagged = true;
                                raggedParents.push(parentId);
                                break;
                            }
                            var format = dataView.table.columns[c].format;
                            var dataType = dataView.table.columns[c].type;
                            var labelValue = visuals.valueFormatter.format(rows[r][c], format);
                            labelValue = labelValue === null ? "(blank)" : labelValue;
                            var value;
                            if (rows[r][c] === null) {
                                value = powerbi.data.SQExprBuilder.nullConstant();
                            }
                            else {
                                if (dataType.text) {
                                    value = powerbi.data.SQExprBuilder.text(rows[r][c]);
                                }
                                else if (dataType.integer) {
                                    value = powerbi.data.SQExprBuilder.integer(rows[r][c]);
                                }
                                else if (dataType.numeric) {
                                    value = powerbi.data.SQExprBuilder.double(rows[r][c]);
                                }
                                else if (dataType.bool) {
                                    value = powerbi.data.SQExprBuilder.boolean(rows[r][c]);
                                }
                                else if (dataType.dateTime) {
                                    value = powerbi.data.SQExprBuilder.dateTime(rows[r][c]);
                                }
                                else {
                                    value = powerbi.data.SQExprBuilder.text(rows[r][c]);
                                }
                            }
                            var filterExpr = powerbi.data.SQExprBuilder.compare(0, dataView.table.columns[c].expr ? dataView.table.columns[c].expr : dataView.categorical.categories[0].identityFields[c], value);
                            if (c > 0) {
                                parentExpr = powerbi.data.SQExprBuilder.and(parentExpr, filterExpr);
                            }
                            else {
                                parentId = "";
                                parentExpr = filterExpr;
                            }
                            var ownId = parentId + (parentId === "" ? "" : '_') + labelValue.replace(/,/g, '') + '-' + c;
                            var isLeaf = c === rows[r].length - 1;
                            var dataPoint = {
                                identity: null,
                                selected: selectedIds.filter(function (d) { return d === ownId; }).length > 0,
                                value: labelValue,
                                tooltip: labelValue,
                                level: c,
                                selectable: true,
                                partialSelected: false,
                                isLeaf: isLeaf,
                                isExpand: expandedIds === [] ? false : expandedIds.filter(function (d) { return d === ownId; }).length > 0 || false,
                                isHidden: c === 0 ? false : true,
                                id: filterExpr,
                                ownId: ownId,
                                parentId: parentId,
                                order: order++,
                            };
                            parentId = ownId;
                            if (identityValues.indexOf(ownId) === -1) {
                                identityValues.push(ownId);
                                dataPoints.push(dataPoint);
                            }
                        }
                    }

                    if (isRagged) {
                        dataPoints.filter(function (d) { raggedParents.filter(function (d1) { d1 === d.ownId }).length > 0 }).forEach(function (d) { d.isLeaf = true });
                    }

                    if (defaultSettings.general.selfFilterEnabled && searchText) {
                        searchText = searchText.toLowerCase();
                        var filteredDataPoints = dataPoints.filter(function (d) { return d.value.toLowerCase().indexOf(searchText) >= 0; });
                        var unique = {};
                        for (var i in filteredDataPoints) {
                            unique[filteredDataPoints[i].ownId] = 0;
                        }
                        for (var l = levels; l >= 1; l--) {
                            var levelDataPoints = filteredDataPoints.filter(function (d) { return d.level === l; });
                            var missingParents = {};
                            for (var i in levelDataPoints) {
                                if (typeof (unique[levelDataPoints[i].parentId]) == "undefined") {
                                    missingParents[levelDataPoints[i].parentId] = 0;
                                }
                                unique[levelDataPoints[i].parentId] = 0;
                            }
                            for (var mp in missingParents) {
                                filteredDataPoints.push(dataPoints.filter(function (d) { return d.ownId === mp; })[0]);
                            }
                        }
                        dataPoints = filteredDataPoints.filter(function (value, index, self) { return self.indexOf(value) === index; }).sort(function (d1, d2) { return d1.order - d2.order; }); // set new dataPoints based on the searchText
                        var parent = {};
                        for (var dp in dataPoints) {
                            if (typeof (parent[dataPoints[dp].parentId]) == "undefined") {
                                parent[dataPoints[dp].parentId] = 0;
                            }
                        }
                        dataPoints.map(function (d) { return d.isLeaf = parent[d.ownId] !== 0; });
                    } else {
                        dataPoints = dataPoints.sort(function (d1, d2) { return d1.order - d2.order; });
                    }
                    // Set isHidden property
                    var parentRootNodes = [];
                    var parentRootNodesTemp = [];
                    var parentRootNodesTotal = [];
                    for (var l = 0; l < levels; l++) {
                        var expandedRootNodes = dataPoints.filter(function (d) { return d.isExpand && d.level === l; });
                        if (expandedRootNodes.length > 0) {
                            for (var n = 0; n < expandedRootNodes.length; n++) {
                                parentRootNodesTemp = parentRootNodes.filter(function (p) { return expandedRootNodes[n].parentId === p.ownId; }); //Is parent expanded?                        
                                if (l === 0 || (parentRootNodesTemp.length > 0)) {
                                    parentRootNodesTotal = parentRootNodesTotal.concat(expandedRootNodes[n]);
                                    dataPoints.filter(function (d) { return d.parentId === expandedRootNodes[n].ownId && d.level === l + 1; }).forEach(function (d) { return d.isHidden = false; });
                                }
                            }
                        }
                        parentRootNodes = parentRootNodesTotal;
                    }
                    return {
                        dataPoints: dataPoints,
                        settings: defaultSettings,
                        levels: levels,
                        hasSelectionOverride: true,
                    };
                };
                HierarchySlicer.prototype.init = function (options) {
                    var _this = this;
                    var hostServices = this.hostServices = options.host;
                    this.element = options.element;
                    this.viewport = options.viewport;
                    this.hostServices = options.host;
                    this.hostServices.canSelect = function () { return true; };
                    this.settings = HierarchySlicer.DefaultSlicerSettings();
                    this.selectionManager = new SelectionManager({ hostServices: options.host });
                    this.selectionManager.clear();
                    if (this.behavior)
                        this.interactivityService = visuals.createInteractivityService(hostServices);
                    this.slicerContainer = d3.select(this.element.get(0)).append('div').classed(HierarchySlicer.Container.class, true);
                    this.slicerHeader = this.slicerContainer.append('div').classed(HierarchySlicer.Header.class, true);
                    this.slicerHeader.append('span').classed(HierarchySlicer.Clear.class, true).attr('title', 'Clear');
                    this.slicerHeader.append('span').classed(HierarchySlicer.Expand.class, true).classed(HierarchySlicer.Clear.class, true).attr('title', 'Expand all');
                    this.slicerHeader.append('span').classed(HierarchySlicer.Collapse.class, true).classed(HierarchySlicer.Clear.class, true).attr('title', 'Collapse all');
                    this.slicerHeader.append('div').classed(HierarchySlicer.HeaderText.class, true);
                    this.createSearchHeader($(this.slicerHeader.node()));
                    this.slicerBody = this.slicerContainer.append('div').classed(HierarchySlicer.Body.class, true).style({
                        'height': PixelConverter.toString(this.viewport.height),
                        'width': PixelConverter.toString(this.viewport.width),
                    });
                    var rowEnter = function (rowSelection) {
                        _this.onEnterSelection(rowSelection);
                    };
                    var rowUpdate = function (rowSelection) {
                        _this.onUpdateSelection(rowSelection, _this.interactivityService);
                    };
                    var rowExit = function (rowSelection) {
                        rowSelection.remove();
                    };
                    var treeViewOptions = {
                        rowHeight: this.getRowHeight(),
                        enter: rowEnter,
                        exit: rowExit,
                        update: rowUpdate,
                        loadMoreData: function () { return _this.onLoadMoreData(); },
                        scrollEnabled: true,
                        viewport: this.getBodyViewport(this.viewport),
                        baseContainer: this.slicerBody,
                        isReadMode: function () {
                            return (_this.hostServices.getViewMode() !== powerbi.ViewMode.Edit);
                        }
                    };
                    this.treeView = TreeViewFactory.createListView(treeViewOptions);
                };
                HierarchySlicer.prototype.update = function (options) {
                    this.viewport = options.viewport;
                    this.dataView = options.dataViews ? options.dataViews[0] : undefined;
                    if (options.viewport.height === this.viewport.height && options.viewport.width === this.viewport.width) {
                        this.waitingForData = false;
                    }
                    this.updateInternal(false);
                    this.checkUpdate();
                };
                HierarchySlicer.prototype.onDataChanged = function (options) {
                    var dataViews = options.dataViews;
                    if (_.isEmpty(dataViews)) {
                        return;
                    }
                    var existingDataView = this.dataView;
                    this.dataView = dataViews[0];
                    var resetScrollbarPosition = options.operationKind !== powerbi.VisualDataChangeOperationKind.Append && !powerbi.DataViewAnalysis.hasSameCategoryIdentity(existingDataView, this.dataView);
                    this.updateInternal(resetScrollbarPosition);
                };
                HierarchySlicer.prototype.onResizing = function (viewPort) {
                    this.viewport = viewPort;
                    this.updateInternal(false);
                };
                HierarchySlicer.prototype.updateInternal = function (resetScrollbar) {
                    var dataView = this.dataView, data = this.data = this.converter(dataView, this.searchInput.val());
                    this.settings = this.data.settings;

                    this.updateSlicerBodyDimensions();
                    this.maxLevels = this.data.levels + 1;
                    if (data.dataPoints.length === 0) {
                        this.treeView.empty();
                        return;
                    }
                    
                    this.updateSettings();
                    this.treeView.viewport(this.getBodyViewport(this.viewport)).rowHeight(this.getRowHeight()).data(data.dataPoints.filter(function (d) { return !d.isHidden; }), function (d) { return $.inArray(d, data.dataPoints); }, resetScrollbar).render();
                    this.updateSearchHeader();
                };
                HierarchySlicer.prototype.updateSettings = function () {
                    this.updateSelectionStyle();
                    this.updateFontStyle();
                    this.updateHeaderStyle();
                };
                HierarchySlicer.prototype.checkUpdate = function () {
                    if (!this.dataView || !this.dataView.metadata || !this.dataView.metadata.objects) {
                        return;
                    }
                    var objects = this.dataView.metadata.objects;
                    var defaultSettings = HierarchySlicer.DefaultSlicerSettings();
                    var codeVersion = defaultSettings.general.version;
                    var currentVersion = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.version, defaultSettings.general.version);
                    if (codeVersion > currentVersion) {
                        var obj = {
                            merge: [
                                {
                                    objectName: "general",
                                    selector: undefined,
                                    properties: {
                                        version: codeVersion,
                                    },
                                }
                            ]
                        };
                        this.hostServices.persistProperties(obj);
                        var warnings = [];
                        warnings.push({
                            code: 'NewVersion',
                            getMessages: function () {
                                var visualMessage = {
                                    message: "Find out what's new at: http://bit.ly/1Uzpp1E",
                                    title: '',
                                    detail: '',
                                };
                                return visualMessage;
                            }
                        });
                    }
                };
                HierarchySlicer.prototype.updateSelectionStyle = function () {
                    var objects = this.dataView && this.dataView.metadata && this.dataView.metadata.objects;
                    if (objects) {
                        this.slicerContainer.classed('isMultiSelectEnabled', !powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selection.singleselect, this.settings.general.singleselect));
                    }
                };
                HierarchySlicer.prototype.updateFontStyle = function () {
                    var objects = this.dataView && this.dataView.metadata && this.dataView.metadata.objects;
                    if (objects) {
                        this.settings.slicerText.fontColor = powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.fontColor, this.settings.slicerText.fontColor);
                        this.settings.slicerText.selectedColor = powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.selectedColor, this.settings.slicerText.selectedColor);
                        this.settings.slicerText.background = powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.background, this.settings.slicerText.background);
                        this.settings.slicerText.textSize = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.textSize, this.settings.slicerText.textSize);
                    }
                };
                HierarchySlicer.prototype.updateHeaderStyle = function () {
                    var objects = this.dataView && this.dataView.metadata && this.dataView.metadata.objects;
                    if (objects) {
                        this.settings.header.show = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.show, this.settings.header.show);
                        this.settings.header.fontColor = powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.fontColor, this.settings.header.fontColor);
                        this.settings.header.background = powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.background, this.settings.header.background);
                        this.settings.header.textSize = powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.textSize, this.settings.header.textSize);
                    }
                };
                HierarchySlicer.prototype.updateSlicerBodyDimensions = function () {
                    var slicerViewport = this.getBodyViewport(this.viewport);
                    this.slicerBody.style({
                        'height': PixelConverter.toString(slicerViewport.height),
                        'width': '100%',
                    });
                };
                HierarchySlicer.prototype.onEnterSelection = function (rowSelection) {
                    var settings = this.settings;
                    if (!settings) {
                        return
                    }
                    var treeItemElementParent = rowSelection.append('li').classed(HierarchySlicer.ItemContainer.class, true)
                    treeItemElementParent.style({ 'background-color': settings.slicerText.background });
                    // Expand/collapse
                    if (this.maxLevels > 1) {
                        treeItemElementParent.each(function (d, i) {
                            var item = d3.select(this);
                            item.append('div').classed(HierarchySlicer.ItemContainerExpander.class, true).append('i').classed("collapse-icon", true).classed("expanded-icon", d.isExpand).style("visibility", d.isLeaf ? "hidden" : "visible");
                        });
                    }
                    var treeItemElement = treeItemElementParent.append('div').classed(HierarchySlicer.ItemContainerChild.class, true);
                    var labelElement = treeItemElement.append('div').classed(HierarchySlicer.Input.class, true);
                    labelElement.append('input').attr('type', 'checkbox');
                    labelElement.append('span').classed(HierarchySlicer.Checkbox.class, true);
                    treeItemElement.each(function (d, i) {
                        var item = d3.select(this);
                        item.append('span').classed(HierarchySlicer.LabelText.class, true).style({
                            'color': settings.slicerText.fontColor,
                            'font-size': PixelConverter.fromPoint(settings.slicerText.textSize)
                        });
                    });
                    var maxLevel = this.maxLevels;
                    treeItemElementParent.each(function (d, i) {
                        var item = d3.select(this);
                        item.style('padding-left', (maxLevel === 1 ? 8 : (d.level * 15)) + 'px');
                    });
                };
                HierarchySlicer.prototype.onUpdateSelection = function (rowSelection, interactivityService) {
                    var settings = this.settings;
                    if (!settings) {
                        return
                    }
                    var data = this.data;
                    if (data) {
                        if (settings.header.show) {
                            this.slicerHeader.style('display', 'block');
                        }
                        else {
                            this.slicerHeader.style('display', 'none');
                        }
                        this.slicerHeader.select(HierarchySlicer.HeaderText.selector).text(settings.header.title.trim()).style({
                            'color': settings.header.fontColor,
                            'background-color': settings.header.background,
                            'border-style': 'solid',
                            'border-color': settings.general.outlineColor,
                            'border-width': this.getBorderWidth(settings.header.outline, settings.header.outlineWeight),
                            'font-size': PixelConverter.fromPoint(settings.header.textSize),
                        });
                        this.slicerBody.classed('slicerBody', true);
                        var slicerText = rowSelection.selectAll(HierarchySlicer.LabelText.selector);
                        slicerText.text(function (d) {
                            return d.value;
                        });
                        if (interactivityService && this.slicerBody) {
                            var body = this.slicerBody.attr('width', this.viewport.width);
                            var expanders = body.selectAll(HierarchySlicer.ItemContainerExpander.selector);
                            var slicerItemContainers = body.selectAll(HierarchySlicer.ItemContainerChild.selector);
                            var slicerItemLabels = body.selectAll(HierarchySlicer.LabelText.selector);
                            var slicerItemInputs = body.selectAll(HierarchySlicer.Input.selector);
                            var slicerClear = this.slicerHeader.select(HierarchySlicer.Clear.selector);
                            var slicerExpand = this.slicerHeader.select(HierarchySlicer.Expand.selector);
                            var slicerCollapse = this.slicerHeader.select(HierarchySlicer.Collapse.selector);
                            var behaviorOptions = {
                                hostServices: this.hostServices,
                                dataPoints: data.dataPoints,
                                expanders: expanders,
                                slicerContainer: this.slicerContainer,
                                slicerItemContainers: slicerItemContainers,
                                slicerItemLabels: slicerItemLabels,
                                slicerItemInputs: slicerItemInputs,
                                slicerClear: slicerClear,
                                slicerExpand: slicerExpand,
                                slicerCollapse: slicerCollapse,
                                interactivityService: interactivityService,
                                slicerSettings: data.settings,
                                levels: data.levels,
                            };
                            try {
                                interactivityService.bind(data.dataPoints, this.behavior, behaviorOptions, {
                                    overrideSelectionFromData: true,
                                    hasSelectionOverride: data.hasSelectionOverride
                                });
                            }
                            catch (e) {
                            }
                            this.behavior.styleSlicerInputs(rowSelection.select(HierarchySlicer.ItemContainerChild.selector), interactivityService.hasSelection());
                        }
                        else {
                            this.behavior.styleSlicerInputs(rowSelection.select(HierarchySlicer.ItemContainerChild.selector), false);
                        }
                    }
                };
                HierarchySlicer.prototype.onLoadMoreData = function () {
                    if (!this.waitingForData && this.dataView.metadata && this.dataView.metadata.segment) {
                        this.hostServices.loadMoreData();
                        this.waitingForData = true;
                    }
                };
                HierarchySlicer.getTextProperties = function (textSize) {
                    return {
                        fontFamily: HierarchySlicer.DefaultFontFamily,
                        fontSize: PixelConverter.fromPoint(textSize || HierarchySlicer.DefaultFontSizeInPt),
                    };
                };
                HierarchySlicer.prototype.getSearchHeight = function () {
                    return this.searchHeader.height() + 2; // 2 for marge
                }
                HierarchySlicer.prototype.getHeaderHeight = function () {
                    return powerbi.TextMeasurementService.estimateSvgTextHeight(HierarchySlicer.getTextProperties(this.settings.header.textSize));
                };
                HierarchySlicer.prototype.getRowHeight = function () {
                    return powerbi.TextMeasurementService.estimateSvgTextHeight(HierarchySlicer.getTextProperties(this.settings.slicerText.textSize));
                };
                HierarchySlicer.prototype.getBodyViewport = function (currentViewport) {
                    var settings = this.settings;
                    var headerHeight;
                    var slicerBodyHeight;
                    if (settings) {
                        headerHeight = settings.header.show ? this.getHeaderHeight() : 0;
                        headerHeight += settings.general.selfFilterEnabled ? this.getSearchHeight() : 0;
                        slicerBodyHeight = currentViewport.height - (headerHeight + settings.header.borderBottomWidth);
                    }
                    else {
                        headerHeight = 0;
                        slicerBodyHeight = currentViewport.height - (headerHeight + 1);
                    }
                    return {
                        height: slicerBodyHeight,
                        width: currentViewport.width
                    };
                };
                HierarchySlicer.prototype.getBorderWidth = function (outlineElement, outlineWeight) {
                    switch (outlineElement) {
                        case 'None':
                            return '0px';
                        case 'BottomOnly':
                            return '0px 0px ' + outlineWeight + 'px 0px';
                        case 'TopOnly':
                            return outlineWeight + 'px 0px 0px 0px';
                        case 'TopBottom':
                            return outlineWeight + 'px 0px ' + outlineWeight + 'px 0px';
                        case 'LeftRight':
                            return '0px ' + outlineWeight + 'px 0px ' + outlineWeight + 'px';
                        case 'Frame':
                            return outlineWeight + 'px';
                        default:
                            return outlineElement.replace("1", outlineWeight.toString());
                    }
                };
                HierarchySlicer.prototype.createSearchHeader = function (container) {
                    var _this = this;
                    this.searchHeader = $("<div>").appendTo(container).addClass("searchHeader").addClass("collapsed");
                    var counter = 0;
                    $("<div>").appendTo(this.searchHeader).attr("title", "Search").addClass("powervisuals-glyph").addClass("search").on("click", function () { return _this.hostServices.persistProperties({
                        merge: [{
                            objectName: "general",
                            selector: null,
                            properties: {
                                counter: counter++
                            }
                        }]
                    }); });
                    this.searchInput = $("<input>").appendTo(this.searchHeader).attr("type", "text").attr("drag-resize-disabled", "true").addClass("searchInput").on("input", function () { return _this.hostServices.persistProperties({
                        merge: [{
                            objectName: "general",
                            selector: null,
                            properties: {
                                counter: counter++
                            }
                        }]
                    }); });
                    $("<div>").appendTo(this.searchHeader).attr("title", "Delete").addClass("delete glyphicon pbi-glyph-close glyph-micro").addClass("delete").on("click", function () {
                        _this.searchInput[0].value = "";
                        _this.hostServices.persistProperties({
                            merge: [{
                                objectName: "general",
                                selector: null,
                                properties: {
                                    counter: counter++
                                }
                            }]
                        });
                    });
                };
                HierarchySlicer.prototype.updateSearchHeader = function () {
                    this.searchHeader.toggleClass("show", this.settings.general.selfFilterEnabled);
                    this.searchHeader.toggleClass("collapsed", !this.settings.general.selfFilterEnabled);
                };
                HierarchySlicer.prototype.enumerateObjectInstances = function (options) {
                    var instances = [];
                    var objects = this.dataView.metadata.objects;
                    switch (options.objectName) {
                        case "selection":
                            var selectionOptions = {
                                objectName: "selection",
                                displayName: "Selection",
                                selector: null,
                                properties: {
                                    singleSelect: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selection.singleselect, this.settings.general.singleselect),
                                    emptyLeafs: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.selection.emptyLeafs, this.settings.general.emptyLeafs)
                                }
                            };
                            instances.push(selectionOptions);
                            break;
                        case "header":
                            var headerOptions = {
                                objectName: "header",
                                displayName: "Header",
                                selector: null,
                                properties: {
                                    show: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.show, this.settings.header.show),
                                    title: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.title, this.settings.header.title),
                                    fontColor: powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.fontColor, this.settings.header.fontColor),
                                    background: powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.background, this.settings.header.background),
                                    textSize: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.header.textSize, this.settings.header.textSize),
                                }
                            };
                            instances.push(headerOptions);
                            break;
                        case "items":
                            var items = {
                                objectName: "items",
                                displayName: "Items",
                                selector: null,
                                properties: {
                                    fontColor: powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.fontColor, this.settings.slicerText.fontColor),
                                    selectedColor: powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.selectedColor, this.settings.slicerText.selectedColor),
                                    background: powerbi.DataViewObjects.getFillColor(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.background, this.settings.slicerText.background),
                                    textSize: powerbi.DataViewObjects.getValue(objects, HierarchySlicer1458836712039.hierarchySlicerProperties.items.textSize, this.settings.slicerText.textSize),
                                }
                            };
                            instances.push(items);
                            break;
                    }
                    return instances;
                };
                HierarchySlicer.capabilities = {
                    dataRoles: [{
                        name: 'Fields',
                        kind: powerbi.VisualDataRoleKind.Grouping,
                        displayName: 'Fields'
                    }, {
                        name: 'Values',
                        kind: powerbi.VisualDataRoleKind.Measure,
                        displayName: 'Values',
                    }],
                    dataViewMappings: [{
                        conditions: [{
                            'Values': { min: 0, max: 1 }
                        }],
                        table: {
                            rows: {
                                select: 
                                [
                                    {for: { in: 'Fields' } },
                                    {for: { in: 'Values' } }
                                ], dataReductionAlgorithm: { bottom: { count: 4000 } }
                            },
                        }
                    }],
                    objects: {
                        general: {
                            displayName: 'General',
                            properties: {
                                filter: {
                                    type: { filter: {} }
                                },
                                filterValues: {
                                    type: { text: true }
                                },
                                expanded: {
                                    type: { text: true }
                                },
                                hidden: {
                                    type: { text: true }
                                },
                                defaultValue: {
                                    type: { expression: { defaultValue: true } },
                                },
                                formatString: {
                                    type: {
                                        formatting: { formatString: true }
                                    },
                                },
                                selfFilter: {
                                    type: { filter: { selfFilter: true } },
                                },
                                selfFilterEnabled: {
                                    type: { operations: { searchEnabled: true } }
                                },
                                version: {
                                    type: { numeric: true }
                                },
                            },
                        },
                        selection: {
                            displayName: 'Selection',
                            properties: {
                                singleSelect: {
                                    displayName: 'Single Select',
                                    type: { bool: true }
                                },
                                emptyLeafs: {
                                    displayName: 'Empty Leafs',
                                    description: 'Show empty leafs as (Blank)',
                                    type: { bool: true }
                                }
                            },
                        },
                        header: {
                            displayName: 'Header',
                            properties: {
                                show: {
                                    displayName: "Show",
                                    type: { bool: true }
                                },
                                title: {
                                    displayName: 'Title',
                                    type: { text: true }
                                },
                                fontColor: {
                                    displayName: 'Font color',
                                    description: 'Font color of the title',
                                    type: { fill: { solid: { color: true } } }
                                },
                                background: {
                                    displayName: 'Background',
                                    type: { fill: { solid: { color: true } } }
                                },
                                textSize: {
                                    displayName: 'Text Size',
                                    type: { formatting: { fontSize: true } }
                                },
                            },
                        },
                        items: {
                            displayName: 'Items',
                            properties: {
                                fontColor: {
                                    displayName: 'Font color',
                                    description: 'Font color of the cells',
                                    type: { fill: { solid: { color: true } } }
                                },
                                selectedColor: {
                                    displayName: 'Select color',
                                    description: 'Font color of the selected cells',
                                    type: { fill: { solid: { color: true } } }
                                },
                                background: {
                                    displayName: 'Background',
                                    type: { fill: { solid: { color: true } } }
                                },
                                textSize: {
                                    displayName: 'Text Size',
                                    type: { formatting: { fontSize: true } }
                                },
                            },
                        }
                    },
                    supportsHighlight: true,
                    suppressDefaultTitle: true,
                    filterMappings: {
                        measureFilter: { targetRoles: ['Fields'] },
                    },
                };
                HierarchySlicer.formatStringProp = {
                    objectName: "general",
                    propertyName: "formatString",
                };
                HierarchySlicer.DefaultFontFamily = 'Segoe UI, Tahoma, Verdana, Geneva, sans-serif';
                HierarchySlicer.DefaultFontSizeInPt = 11;
                HierarchySlicer.Container = createClassAndSelector('slicerContainer');
                HierarchySlicer.Body = createClassAndSelector('slicerBody');
                HierarchySlicer.ItemContainer = createClassAndSelector('slicerItemContainer');
                HierarchySlicer.ItemContainerExpander = createClassAndSelector('slicerItemContainerExpander');
                HierarchySlicer.ItemContainerChild = createClassAndSelector('slicerItemContainerChild');
                HierarchySlicer.LabelText = createClassAndSelector('slicerText');
                HierarchySlicer.CountText = createClassAndSelector('slicerCountText');
                HierarchySlicer.Checkbox = createClassAndSelector('checkbox');
                HierarchySlicer.Header = createClassAndSelector('slicerHeader');
                HierarchySlicer.HeaderText = createClassAndSelector('headerText');
                HierarchySlicer.Collapse = createClassAndSelector('collapse');
                HierarchySlicer.Expand = createClassAndSelector('expand');
                HierarchySlicer.Clear = createClassAndSelector('clear');
                HierarchySlicer.Input = createClassAndSelector('slicerCheckbox');
                return HierarchySlicer;
            })();
            HierarchySlicer1458836712039.HierarchySlicer = HierarchySlicer;
        })(HierarchySlicer1458836712039 = visuals.HierarchySlicer1458836712039 || (visuals.HierarchySlicer1458836712039 = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var plugins;
        (function (plugins) {
            plugins.HierarchySlicer1458836712039 = {
                name: 'HierarchySlicer1458836712039',
                class: 'HierarchySlicer1458836712039',
                capabilities: powerbi.visuals.HierarchySlicer1458836712039.HierarchySlicer.capabilities,
                custom: true,
                create: function (options) { return new powerbi.visuals.HierarchySlicer1458836712039.HierarchySlicer(options); },
                apiVersion: null
            };
        })(plugins = visuals.plugins || (visuals.plugins = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
